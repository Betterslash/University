from queue import PriorityQueue

import pygame
from pygame.locals import *


class Drone:
    def __init__(self, x, y):
        self._x = x
        self._y = y
        self.open_list = []
        self.close_list = dict()
        self.open_list.append((0, (self._x, self._y)))
        self.visited = []
        self.priority_queue = PriorityQueue()

    def get_X(self):
        return self._x

    def get_Y(self):
        return self._y

    def move(self, detectedMap):
        pressed_keys = pygame.key.get_pressed()
        if self.x > 0:
            if pressed_keys[K_UP] and detectedMap.surface[self.x - 1][self.y] == 0:
                self.x = self.x - 1
        if self.x < 19:
            if pressed_keys[K_DOWN] and detectedMap.surface[self.x + 1][self.y] == 0:
                self.x = self.x + 1

        if self.y > 0:
            if pressed_keys[K_LEFT] and detectedMap.surface[self.x][self.y - 1] == 0:
                self.y = self.y - 1
        if self.y < 19:
            if pressed_keys[K_RIGHT] and detectedMap.surface[self.x][self.y + 1] == 0:
                self.y = self.y + 1

    def mapWithDrone(self, mapImage):
        drona = pygame.image.load("drona.png")
        mapImage.blit(drona, (self.y * 20, self.x * 20))

        return mapImage


