from taks1.Model.MapClass import Map
from taks1.View.ViewClass import View

if __name__ == "__main__":

    # choice = input()
    view = View()
    view.main()
