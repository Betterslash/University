from controller.Solver import Solver

if __name__ == "__main__":
    solver = Solver()
    solver.run()
