class Constants:

        DATA_PATH = 'database/myDataset.dat'
        DICT_STATES_PATH = 'database/dori.pt'
